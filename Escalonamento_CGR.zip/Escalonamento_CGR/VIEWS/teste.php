<? 
	phpversion();
	phpinfo();

?>