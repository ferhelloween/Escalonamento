<? 
	//Arquivo Index.php - Tem como utilidade carregar o template da página 
	setlocale(LC_ALL, "pt_BR"); 
	header('Content-type: text/html; charset=utf-8');

	

?> 

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<meta name="authors" content="CGR - Governança"/> <!--Autor do sistema - EQUIPE CGR - GOV-->
	<meta http-equiv="X-UA-Compatible" content="ie=11"> <!--Compatibilidade para o internet Explorer 11-->
	<meta http-equiv="X-UA-Compatible" content="IE=edge"><!--Compatibilidade com o Microsoft Edge-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">  

	 <!-- Font Awesome -->
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	 
	 <!-- Ionicons -->
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

	 <!--CSS Bootstrap e Próprios-->
	 <link rel="stylesheet" type="text/css" href="../LIB/CSS/bootstrap.min.css"/> <!--BootStrap-->
	 <link rel="stylesheet" type="text/css" href="../LIB/CSS/newPages.css"/><!--CSS Adicional-->

	 <!--Bootstrap JS--> 
	 <script type="text/javascript" src="../LIB/JS/jquery3.1.1.js"></script>
	 <script type="text/javascript" charset="utf-8" src="../LIB/JS/jquery-1.11.1.min.js"></script> 
	 <script type="text/javascript" charset="utf-8" src="../LIB/JS/bootstrap.min.js"></script>  

	 <!--Auto Complete Source-->
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 	 <link rel="stylesheet" href="/resources/demos/style.css">
  	 <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  	 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>		 

  	 <style type="text/css">
  	 
  	 	body { 
	 		background-color: #F0F8FF !important; 
	 	}	
  	 
  	 </style>
</head>
<body>
	<h1 style="text-align:center; color: #066fa8;">Escalonamento CGR V2</h1> 

	<h2 style="text-align:center; color: #066fa8;">(Clique no menu ao lado para opções)</h2>

</body>
</html>